---
name: Feature request
about: Suggest an idea for this project
title: "[Feature Request]"
labels: enhancement
assignees: ''

---

### Is your feature request related to a problem? If yes, please describe.

<!-- A clear and concise description of what the problem is. Ex. I'm always frustrated when ... -->

### Describe the solution/feature you'd like

<!-- A clear and concise description or list of what you want to happen. -->

### Describe alternatives you've considered

<!-- A clear and concise description of any alternative solutions or features you've considered. -->

### Additional context

<!-- Add any other context or screenshots about the feature request here. -->
